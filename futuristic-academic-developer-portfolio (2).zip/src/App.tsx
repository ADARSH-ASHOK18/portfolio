import {
  Navigation,
  Hero,
  About,
  ExpertiseSpotlight,
  Skills,
  Projects,
  Research,
  Teaching,
  Timeline,
  Testimonials,
  Contact,
  Footer,
  AnimatedBackground,
  FloatingElements,
  CursorGlow,
  ScrollProgress,
} from './components';

export default function App() {
  return (
    <div className="relative w-full overflow-hidden bg-gradient-to-b from-slate-950 via-purple-950 to-slate-950">
      {/* Animated Background */}
      <AnimatedBackground />

      {/* Scroll Progress */}
      <ScrollProgress />

      {/* Cursor Glow */}
      <CursorGlow />

      {/* Floating Elements */}
      <FloatingElements />

      {/* Content */}
      <div className="relative z-20">
        {/* Navigation */}
        <Navigation />

        {/* Hero Section */}
        <section id="home">
          <Hero />
        </section>

        {/* About Section */}
        <section id="about">
          <About />
        </section>

        {/* Expertise Spotlight Section */}
        <section id="expertise">
          <ExpertiseSpotlight />
        </section>

        {/* Skills Section */}
        <section id="skills">
          <Skills />
        </section>

        {/* Projects Section */}
        <section id="projects">
          <Projects />
        </section>

        {/* Research Section */}
        <section id="research">
          <Research />
        </section>

        {/* Teaching Section */}
        <section id="teaching">
          <Teaching />
        </section>

        {/* Timeline Section */}
        <section id="timeline">
          <Timeline />
        </section>

        {/* Testimonials Section */}
        <section id="testimonials">
          <Testimonials />
        </section>

        {/* Contact Section */}
        <section id="contact">
          <Contact />
        </section>

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}
