import React from 'react';
import { motion } from 'framer-motion';

const skillCategories = [
  {
    category: 'Frontend',
    skills: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS', 'Framer Motion'],
    progress: 95,
  },
  {
    category: 'Backend',
    skills: ['Node.js', 'Express', 'PHP', 'Python', 'REST APIs'],
    progress: 92,
  },
  {
    category: 'Databases',
    skills: ['MongoDB', 'MySQL', 'PostgreSQL', 'Redis', 'Firebase'],
    progress: 88,
  },
  {
    category: 'DevOps & Cloud',
    skills: ['Docker', 'AWS', 'GCP', 'CI/CD', 'Kubernetes'],
    progress: 85,
  },
  {
    category: 'AI/ML & Research',
    skills: ['TensorFlow', 'PyTorch', 'Data Analysis', 'NLP', 'Computer Vision'],
    progress: 80,
  },
  {
    category: 'Tools & Methods',
    skills: ['Git', 'Figma', 'Agile', 'Testing', 'Performance Optimization'],
    progress: 90,
  },
];

const SkillCard: React.FC<{ category: string; skills: string[]; progress: number; index: number }> = ({
  category,
  skills,
  progress,
  index,
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      viewport={{ once: true }}
      whileHover={{ y: -10 }}
      className="glass p-8 rounded-xl border border-white/10 hover:border-purple-500/30 transition-all duration-300 group"
    >
      <h3 className="text-xl font-bold text-white mb-4 group-hover:text-cyan-400 transition-colors">{category}</h3>

      {/* Skill tags */}
      <div className="flex flex-wrap gap-2 mb-6">
        {skills.map((skill, idx) => (
          <motion.span
            key={idx}
            initial={{ opacity: 0, scale: 0.8 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.4, delay: idx * 0.05 }}
            className="px-3 py-1 rounded-full text-xs font-semibold bg-gradient-to-r from-cyan-500/20 to-purple-500/20 border border-cyan-500/30 text-cyan-300"
          >
            {skill}
          </motion.span>
        ))}
      </div>

      {/* Progress bar */}
      <div className="space-y-2">
        <div className="flex justify-between items-center">
          <span className="text-sm text-white/60">Proficiency</span>
          <motion.span
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-sm font-semibold text-cyan-400"
          >
            {progress}%
          </motion.span>
        </div>
        <div className="relative w-full h-2 bg-white/10 rounded-full overflow-hidden border border-white/5">
          <motion.div
            initial={{ width: 0 }}
            whileInView={{ width: `${progress}%` }}
            transition={{ duration: 1.2, delay: 0.2 }}
            className="h-full bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400 rounded-full shadow-lg shadow-purple-500/50"
          />
        </div>
      </div>
    </motion.div>
  );
};

export const Skills: React.FC = () => {
  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Skills & Expertise</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            A comprehensive skill set spanning modern web development, research methodologies, and cutting-edge technologies.
          </p>
        </motion.div>

        {/* Skills Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((item, index) => (
            <SkillCard key={index} {...item} index={index} />
          ))}
        </div>

        {/* Floating tech icons background */}
        <div className="mt-20 pt-16 border-t border-white/5">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h3 className="text-2xl font-bold mb-8">Technologies I Work With</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-6">
              {['React', 'Node.js', 'TypeScript', 'Python', 'Docker', 'AWS', 'MongoDB', 'TensorFlow', 'PostgreSQL', 'GraphQL', 'Kubernetes', 'FastAPI'].map(
                (tech, index) => (
                  <motion.div
                    key={index}
                    whileHover={{ scale: 1.15, boxShadow: '0 0 25px rgba(168, 85, 247, 0.5)' }}
                    className="glass p-4 rounded-lg border border-white/10 cursor-pointer hover:border-purple-500/50 transition-all"
                  >
                    <p className="font-semibold text-center text-sm text-white/80">{tech}</p>
                  </motion.div>
                )
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};
