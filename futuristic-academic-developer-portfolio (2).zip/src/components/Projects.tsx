import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiGithub, FiExternalLink, FiCode } from 'react-icons/fi';

const projects = [
  {
    id: 1,
    title: 'AI Research Platform',
    description: 'A comprehensive platform for conducting AI research with real-time collaboration features and advanced data visualization.',
    category: 'AI Projects',
    technologies: ['React', 'Node.js', 'TensorFlow', 'MongoDB'],
    image: 'bg-gradient-to-br from-cyan-500/20 to-blue-600/20',
    featured: true,
  },
  {
    id: 2,
    title: 'Full Stack E-Commerce',
    description: 'Modern e-commerce platform with real-time inventory, payment integration, and advanced analytics.',
    category: 'Web Development',
    technologies: ['Next.js', 'TypeScript', 'PostgreSQL', 'Stripe'],
    image: 'bg-gradient-to-br from-purple-500/20 to-pink-600/20',
    featured: true,
  },
  {
    id: 3,
    title: 'IoT Smart Home System',
    description: 'Connected IoT ecosystem for smart home automation with mobile app and cloud integration.',
    category: 'IoT Projects',
    technologies: ['Python', 'Arduino', 'Firebase', 'React Native'],
    image: 'bg-gradient-to-br from-green-500/20 to-emerald-600/20',
    featured: false,
  },
  {
    id: 4,
    title: 'Research Paper Analysis Tool',
    description: 'Advanced tool for analyzing academic papers using NLP and machine learning techniques.',
    category: 'Research Work',
    technologies: ['Python', 'NLP', 'FastAPI', 'PostgreSQL'],
    image: 'bg-gradient-to-br from-orange-500/20 to-red-600/20',
    featured: false,
  },
  {
    id: 5,
    title: 'Real-time Collaboration Suite',
    description: 'Collaborative workspace for teams with video conferencing, code sharing, and real-time editing.',
    category: 'Web Development',
    technologies: ['React', 'WebSocket', 'WebRTC', 'Node.js'],
    image: 'bg-gradient-to-br from-indigo-500/20 to-purple-600/20',
    featured: true,
  },
  {
    id: 6,
    title: 'Computer Vision System',
    description: 'Advanced computer vision system for object detection and image analysis using deep learning.',
    category: 'AI Projects',
    technologies: ['Python', 'OpenCV', 'PyTorch', 'Flask'],
    image: 'bg-gradient-to-br from-teal-500/20 to-cyan-600/20',
    featured: false,
  },
];

const categories = ['All', 'Web Development', 'AI Projects', 'IoT Projects', 'Research Work'];

const ProjectCard: React.FC<{
  title: string;
  description: string;
  technologies: string[];
  image: string;
  featured?: boolean;
}> = ({ title, description, technologies, image, featured }) => {
  return (
    <motion.div
      whileHover={{ y: -15 }}
      className={`group relative overflow-hidden rounded-2xl border border-white/10 hover:border-purple-500/30 transition-all duration-300 ${
        featured ? 'md:col-span-2 md:row-span-2' : ''
      }`}
    >
      {/* Background */}
      <div className={`absolute inset-0 ${image}`} />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/30 to-slate-950" />

      {/* Content */}
      <div className="relative h-full min-h-96 p-8 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between mb-6">
            <FiCode className="text-cyan-400 group-hover:text-purple-400 transition-colors" size={28} />
            <motion.div whileHover={{ rotate: 45 }} className="cursor-pointer">
              <FiExternalLink className="text-white/40 group-hover:text-cyan-400 transition-colors" size={24} />
            </motion.div>
          </div>

          <h3 className="text-2xl md:text-3xl font-bold mb-4 text-white">{title}</h3>
          <p className="text-white/70 mb-6 leading-relaxed">{description}</p>
        </div>

        {/* Footer */}
        <div className="space-y-6">
          <div className="flex flex-wrap gap-2">
            {technologies.map((tech, idx) => (
              <motion.span
                key={idx}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.3, delay: idx * 0.05 }}
                className="px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/10 border border-cyan-500/20 text-cyan-300"
              >
                {tech}
              </motion.span>
            ))}
          </div>

          <div className="flex gap-4 pt-4 border-t border-white/10">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 text-white/60 hover:text-cyan-400 transition-colors"
            >
              <FiGithub size={20} />
              <span className="text-sm">Code</span>
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center gap-2 text-white/60 hover:text-purple-400 transition-colors"
            >
              <FiExternalLink size={20} />
              <span className="text-sm">Live Demo</span>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Hover glow effect */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-gradient-to-r from-cyan-500/0 via-purple-500/10 to-pink-500/0 pointer-events-none" />
    </motion.div>
  );
};

export const Projects: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProjects =
    activeCategory === 'All' ? projects : projects.filter((p) => p.category === activeCategory);

  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Featured Projects</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            A curated selection of projects showcasing expertise in web development, AI research, and innovative solutions.
          </p>
        </motion.div>

        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category) => (
            <motion.button
              key={category}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setActiveCategory(category)}
              className={`px-6 py-2 rounded-full font-semibold transition-all duration-300 border ${
                activeCategory === category
                  ? 'bg-gradient-to-r from-cyan-500 to-purple-500 border-cyan-400 text-white'
                  : 'glass border-white/20 text-white/60 hover:border-purple-500/50'
              }`}
            >
              {category}
            </motion.button>
          ))}
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 auto-rows-max"
        >
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              layout
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <ProjectCard {...project} />
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
};
