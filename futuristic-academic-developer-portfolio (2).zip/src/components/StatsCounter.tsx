import React from 'react';
import { motion } from 'framer-motion';

interface StatProps {
  value: number;
  label: string;
  suffix?: string;
  icon: string;
  delay: number;
}

const useInViewHook = ({ triggerOnce, threshold }: { triggerOnce: boolean; threshold: number }) => {
  const [inView, setInView] = React.useState(false);
  const ref = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
          if (triggerOnce) {
            observer.unobserve(entry.target);
          }
        } else if (!triggerOnce) {
          setInView(false);
        }
      },
      { threshold }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => {
      if (ref.current) {
        observer.unobserve(ref.current);
      }
    };
  }, [triggerOnce, threshold]);

  return { ref, inView };
};

const StatCounter: React.FC<StatProps> = ({ value, label, suffix = '', icon, delay }) => {
  const { ref, inView } = useInViewHook({ triggerOnce: true, threshold: 0.5 });
  const [displayValue, setDisplayValue] = React.useState(0);

  React.useEffect(() => {
    if (!inView) return;

    const interval = setInterval(() => {
      setDisplayValue((prev) => {
        if (prev >= value) {
          clearInterval(interval);
          return value;
        }
        return prev + Math.ceil(value / 50);
      });
    }, 50);

    return () => {
      clearInterval(interval);
    };
  }, [inView, value]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 40 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 40 }}
      transition={{ duration: 0.6, delay }}
      whileHover={{ y: -10, boxShadow: '0 0 30px rgba(34, 211, 238, 0.3)' }}
      className="glass p-8 rounded-xl border border-white/10 hover:border-cyan-500/30 transition-all duration-300 text-center group"
    >
      <div className="text-4xl mb-4 group-hover:scale-125 transition-transform duration-300">
        {icon}
      </div>
      <div className="flex items-baseline justify-center gap-1 mb-3">
        <span className="text-4xl md:text-5xl font-bold gradient-text">
          {Math.min(displayValue, value)}
        </span>
        {suffix && <span className="text-2xl text-cyan-400">{suffix}</span>}
      </div>
      <p className="text-white/60 font-semibold">{label}</p>
    </motion.div>
  );
};



export const StatsCounter: React.FC = () => {
  const stats = [
    { value: 8, label: 'Years of Teaching', suffix: '+', icon: '📚' },
    { value: 500, label: 'Students Mentored', suffix: '+', icon: '👥' },
    { value: 25, label: 'Research Papers', suffix: '+', icon: '📰' },
    { value: 50, label: 'Projects Completed', suffix: '+', icon: '💻' },
  ];

  return (
    <section className="relative py-20 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-4xl md:text-5xl font-bold text-center mb-12 gradient-text"
        >
          By The Numbers
        </motion.h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <StatCounter
              key={index}
              value={stat.value}
              label={stat.label}
              suffix={stat.suffix}
              icon={stat.icon}
              delay={index * 0.15}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
