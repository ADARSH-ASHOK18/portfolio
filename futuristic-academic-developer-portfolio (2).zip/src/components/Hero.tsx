import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FiDownload, FiArrowRight } from 'react-icons/fi';

const skills = ['Full Stack Development', 'AI/ML Integration', 'Research & Innovation', 'Mentoring'];

export const Hero: React.FC = () => {
  const [displayedText, setDisplayedText] = useState('');
  const [skillIndex, setSkillIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);

  useEffect(() => {
    const currentSkill = skills[skillIndex];
    if (charIndex < currentSkill.length) {
      const timer = setTimeout(() => {
        setDisplayedText(prev => prev + currentSkill[charIndex]);
        setCharIndex(charIndex + 1);
      }, 100);
      return () => clearTimeout(timer);
    } else {
      const timer = setTimeout(() => {
        setDisplayedText('');
        setCharIndex(0);
        setSkillIndex((skillIndex + 1) % skills.length);
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [charIndex, skillIndex]);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.3,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.8 },
    },
  };

  return (
    <section className="relative min-h-screen w-full flex items-center justify-center px-4 py-20 overflow-hidden" style={{ zIndex: 10 }}>
      <motion.div
        className="max-w-5xl w-full mx-auto"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Glowing background circles */}
        <div className="absolute -top-40 -right-40 w-80 h-80 bg-purple-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -left-40 w-80 h-80 bg-cyan-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Main content */}
        <div className="relative z-10 text-center space-y-8">
          {/* Greeting */}
          <motion.div variants={itemVariants} className="inline-block">
            <div className="glass px-6 py-2 rounded-full border border-cyan-500/30">
              <p className="text-cyan-400 text-sm font-medium">Welcome to my portfolio</p>
            </div>
          </motion.div>

          {/* Name */}
          <motion.h1
            variants={itemVariants}
            className="text-6xl md:text-7xl font-bold mb-6 leading-tight"
          >
            <span className="gradient-text">Dr. Alex Chen</span>
          </motion.h1>

          {/* Title with typing effect */}
          <motion.div variants={itemVariants} className="space-y-4">
            <p className="text-2xl md:text-3xl font-light text-white/80">
              Assistant Professor | Full Stack Developer
            </p>
            <div className="h-12 flex items-center justify-center">
              <p className="text-xl md:text-2xl text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-purple-400 to-pink-400">
                {displayedText}
                <span className="animate-pulse">|</span>
              </p>
            </div>
          </motion.div>

          {/* Description */}
          <motion.p
            variants={itemVariants}
            className="text-lg text-white/60 max-w-2xl mx-auto leading-relaxed"
          >
            Pioneering the intersection of academic research and cutting-edge web development. 
            Building intelligent systems, mentoring the next generation, and crafting digital experiences 
            that matter.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-8"
          >
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(168, 85, 247, 0.6)' }}
              whileTap={{ scale: 0.95 }}
              className="glass px-8 py-4 rounded-lg font-semibold text-white flex items-center gap-2 border border-purple-500/50 hover:border-purple-400 group"
            >
              View My Work
              <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(34, 211, 238, 0.6)' }}
              whileTap={{ scale: 0.95 }}
              className="glass px-8 py-4 rounded-lg font-semibold text-white flex items-center gap-2 border border-cyan-500/50 hover:border-cyan-400 group"
            >
              <FiDownload className="group-hover:scale-110 transition-transform" />
              Download CV
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(236, 72, 153, 0.6)' }}
              whileTap={{ scale: 0.95 }}
              className="glass px-8 py-4 rounded-lg font-semibold text-white border border-pink-500/50 hover:border-pink-400"
            >
              Get in Touch
            </motion.button>
          </motion.div>

          {/* Scroll indicator */}
          <motion.div
            variants={itemVariants}
            className="pt-12 flex flex-col items-center"
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <p className="text-white/40 text-sm mb-4">Scroll to explore</p>
            <div className="w-6 h-10 border-2 border-white/40 rounded-full flex justify-center">
              <motion.div
                className="w-1 h-2 bg-white/40 rounded-full mt-2"
                animate={{ y: [0, 8, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              />
            </div>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};
