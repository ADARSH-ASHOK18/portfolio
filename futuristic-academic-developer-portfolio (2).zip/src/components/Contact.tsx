import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { FiMail, FiPhone, FiMapPin, FiGithub, FiLinkedin, FiTwitter, FiArrowRight } from 'react-icons/fi';

export const Contact: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  const contactInfo = [
    { icon: FiMail, label: 'Email', value: 'alex@techuniversity.edu', href: 'mailto:alex@techuniversity.edu' },
    { icon: FiPhone, label: 'Phone', value: '+1 (555) 123-4567', href: 'tel:+15551234567' },
    { icon: FiMapPin, label: 'Location', value: 'San Francisco, CA', href: '#' },
  ];

  const socialLinks = [
    { icon: FiGithub, label: 'GitHub', href: 'https://github.com' },
    { icon: FiLinkedin, label: 'LinkedIn', href: 'https://linkedin.com' },
    { icon: FiTwitter, label: 'Twitter', href: 'https://twitter.com' },
  ];

  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/20 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Get In Touch</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Let's discuss your project, collaborate on research, or just have a conversation about technology and innovation.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12 mb-16">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <label className="block text-white/80 font-semibold text-sm">Name</label>
                <motion.input
                  whileFocus={{ boxShadow: '0 0 20px rgba(34, 211, 238, 0.3)' }}
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full glass px-6 py-4 rounded-lg border border-white/20 focus:border-cyan-500 focus:outline-none transition-all duration-300 text-white placeholder-white/30"
                  placeholder="Your name"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-white/80 font-semibold text-sm">Email</label>
                <motion.input
                  whileFocus={{ boxShadow: '0 0 20px rgba(34, 211, 238, 0.3)' }}
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full glass px-6 py-4 rounded-lg border border-white/20 focus:border-cyan-500 focus:outline-none transition-all duration-300 text-white placeholder-white/30"
                  placeholder="your.email@example.com"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-white/80 font-semibold text-sm">Subject</label>
                <motion.input
                  whileFocus={{ boxShadow: '0 0 20px rgba(34, 211, 238, 0.3)' }}
                  type="text"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="w-full glass px-6 py-4 rounded-lg border border-white/20 focus:border-cyan-500 focus:outline-none transition-all duration-300 text-white placeholder-white/30"
                  placeholder="What's this about?"
                />
              </div>

              <div className="space-y-2">
                <label className="block text-white/80 font-semibold text-sm">Message</label>
                <motion.textarea
                  whileFocus={{ boxShadow: '0 0 20px rgba(34, 211, 238, 0.3)' }}
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full glass px-6 py-4 rounded-lg border border-white/20 focus:border-cyan-500 focus:outline-none transition-all duration-300 text-white placeholder-white/30 resize-none"
                  placeholder="Your message..."
                />
              </div>

              <motion.button
                whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(168, 85, 247, 0.6)' }}
                whileTap={{ scale: 0.95 }}
                type="submit"
                className="w-full glass px-6 py-4 rounded-lg font-bold text-white border border-purple-500/50 hover:border-purple-400 flex items-center justify-center gap-2 group transition-all duration-300"
              >
                Send Message
                <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
              </motion.button>
            </form>
          </motion.div>

          {/* Contact Info */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            {/* Contact Details */}
            <div className="space-y-4">
              {contactInfo.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.a
                    key={index}
                    href={item.href}
                    initial={{ opacity: 0, x: 40 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.6, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{ x: 10, color: '#06b6d4' }}
                    className="glass p-6 rounded-lg border border-white/10 hover:border-cyan-500/30 transition-all duration-300 group flex items-start gap-4"
                  >
                    <div className="text-cyan-400 group-hover:text-purple-400 transition-colors flex-shrink-0 mt-1">
                      <Icon size={24} />
                    </div>
                    <div>
                      <p className="text-white/60 text-sm font-semibold">{item.label}</p>
                      <p className="text-white font-semibold mt-1 group-hover:text-cyan-400 transition-colors">
                        {item.value}
                      </p>
                    </div>
                  </motion.a>
                );
              })}
            </div>

            {/* Social Links */}
            <div className="pt-8 border-t border-white/10">
              <p className="text-white/80 font-semibold mb-6">Follow & Connect</p>
              <div className="flex gap-4">
                {socialLinks.map((link, index) => {
                  const Icon = link.icon;
                  return (
                    <motion.a
                      key={index}
                      href={link.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.4, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      whileHover={{
                        scale: 1.2,
                        boxShadow: '0 0 20px rgba(168, 85, 247, 0.5)',
                      }}
                      className="glass p-4 rounded-lg border border-white/20 hover:border-purple-500/50 transition-all duration-300 flex items-center justify-center text-white hover:text-purple-400"
                    >
                      <Icon size={24} />
                    </motion.a>
                  );
                })}
              </div>
            </div>

            {/* Quick Message */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.3 }}
              viewport={{ once: true }}
              className="glass p-6 rounded-lg border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-purple-500/10"
            >
              <p className="text-white/80">
                📬 I typically respond within 24 hours. Feel free to reach out with any questions, collaboration opportunities, or just to say hello!
              </p>
            </motion.div>
          </motion.div>
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center pt-12 border-t border-white/10"
        >
          <p className="text-white/60 mb-6">Or schedule a quick call with me</p>
          <motion.button
            whileHover={{ scale: 1.05, boxShadow: '0 0 30px rgba(34, 211, 238, 0.6)' }}
            whileTap={{ scale: 0.95 }}
            className="glass px-10 py-4 rounded-lg font-bold text-white border border-cyan-500/50 hover:border-cyan-400 flex items-center justify-center gap-2 group mx-auto transition-all duration-300"
          >
            <FiCalendar className="group-hover:rotate-12 transition-transform" />
            Schedule a Meeting
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};

import { FiCalendar } from 'react-icons/fi';
