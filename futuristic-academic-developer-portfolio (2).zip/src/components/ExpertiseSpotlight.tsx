import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const expertiseAreas = [
  {
    title: 'Full Stack Web Development',
    description: 'Building scalable, performant applications with modern tech stacks',
    icon: '🌐',
    color: 'from-cyan-500/20 to-blue-600/20',
  },
  {
    title: 'AI & Machine Learning Integration',
    description: 'Implementing intelligent systems and predictive models in production',
    icon: '🤖',
    color: 'from-purple-500/20 to-pink-600/20',
  },
  {
    title: 'Cloud Architecture & DevOps',
    description: 'Designing and deploying highly available, scalable systems',
    icon: '☁️',
    color: 'from-green-500/20 to-emerald-600/20',
  },
  {
    title: 'Research & Innovation',
    description: 'Conducting cutting-edge research and publishing findings',
    icon: '🔬',
    color: 'from-orange-500/20 to-red-600/20',
  },
  {
    title: 'Mentoring & Education',
    description: 'Guiding the next generation of developers and researchers',
    icon: '📚',
    color: 'from-indigo-500/20 to-purple-600/20',
  },
];

export const ExpertiseSpotlight: React.FC = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(true);

  useEffect(() => {
    if (!autoPlay) return;

    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % expertiseAreas.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [autoPlay]);

  const current = expertiseAreas[activeIndex];

  return (
    <section className="relative py-20 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          onMouseEnter={() => setAutoPlay(false)}
          onMouseLeave={() => setAutoPlay(true)}
          className="glass p-8 md:p-12 rounded-2xl border border-white/10 hover:border-purple-500/30 transition-all duration-300"
        >
          <div className="grid md:grid-cols-3 gap-8 items-center">
            {/* Icon and Title */}
            <motion.div
              key={`icon-${activeIndex}`}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              transition={{ duration: 0.5 }}
              className="text-center md:text-left"
            >
              <div className="text-6xl mb-4">{current.icon}</div>
              <h3 className="text-2xl md:text-3xl font-bold text-white mb-2">
                {current.title}
              </h3>
              <p className="text-white/60">{current.description}</p>
            </motion.div>

            {/* Visual Element */}
            <motion.div
              key={`visual-${activeIndex}`}
              initial={{ opacity: 0, rotate: -45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: 45 }}
              transition={{ duration: 0.5 }}
              className={`hidden md:block h-48 rounded-xl bg-gradient-to-br ${current.color} border border-white/10 relative overflow-hidden`}
            >
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                className="absolute inset-0 flex items-center justify-center text-5xl opacity-30"
              >
                {current.icon}
              </motion.div>
            </motion.div>

            {/* Navigation Dots */}
            <div className="flex flex-col gap-4">
              {expertiseAreas.map((area, index) => (
                <motion.button
                  key={index}
                  onClick={() => {
                    setActiveIndex(index);
                    setAutoPlay(false);
                  }}
                  whileHover={{ scale: 1.05 }}
                  className={`text-left px-4 py-3 rounded-lg transition-all duration-300 border ${
                    index === activeIndex
                      ? 'glass border-cyan-500/50 bg-cyan-500/10'
                      : 'glass border-white/10 hover:border-purple-500/30'
                  }`}
                >
                  <p className={`text-sm font-semibold ${index === activeIndex ? 'text-cyan-400' : 'text-white/60'}`}>
                    {area.icon} {area.title}
                  </p>
                </motion.button>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
