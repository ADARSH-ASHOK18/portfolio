import React from 'react';
import { motion } from 'framer-motion';
import { FiBookOpen, FiAward, FiUsers } from 'react-icons/fi';

const courses = [
  {
    code: 'CS501',
    title: 'Advanced Full Stack Web Development',
    description: 'Comprehensive course covering modern web technologies, architecture, and best practices.',
    students: 120,
    rating: 4.9,
  },
  {
    code: 'CS502',
    title: 'Machine Learning Integration for Web Apps',
    description: 'Practical applications of AI/ML in web development with hands-on projects.',
    students: 95,
    rating: 4.8,
  },
  {
    code: 'CS401',
    title: 'Web Application Architecture & Design',
    description: 'Understanding scalable architecture patterns and design principles for modern applications.',
    students: 150,
    rating: 4.7,
  },
  {
    code: 'CS503',
    title: 'Real-time Systems & WebSocket Programming',
    description: 'Building real-time collaborative applications using WebSocket and modern protocols.',
    students: 85,
    rating: 4.9,
  },
];

const certifications = [
  {
    name: 'AWS Certified Solutions Architect',
    issuer: 'Amazon Web Services',
    year: '2023',
    badge: '🏆',
  },
  {
    name: 'Google Cloud Professional Developer',
    issuer: 'Google Cloud',
    year: '2023',
    badge: '☁️',
  },
  {
    name: 'Kubernetes Application Developer',
    issuer: 'Linux Foundation',
    year: '2022',
    badge: '🐳',
  },
  {
    name: 'TensorFlow Certification',
    issuer: 'Google & Deeplearning.AI',
    year: '2022',
    badge: '🤖',
  },
  {
    name: 'Advanced React Developer',
    issuer: 'Udacity',
    year: '2021',
    badge: '⚛️',
  },
  {
    name: 'Full Stack Web Development',
    issuer: 'Stanford University',
    year: '2020',
    badge: '🎓',
  },
];

export const Teaching: React.FC = () => {
  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Teaching & Certifications</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Dedicated to educating the next generation of developers and staying at the forefront of technology.
          </p>
        </motion.div>

        {/* Courses */}
        <div className="mb-20">
          <motion.h3
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-8 flex items-center gap-3"
          >
            <FiBookOpen className="text-cyan-400" />
            Courses Taught
          </motion.h3>

          <div className="grid md:grid-cols-2 gap-6">
            {courses.map((course, index) => (
              <motion.div
                key={course.code}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10, boxShadow: '0 0 30px rgba(34, 211, 238, 0.2)' }}
                className="glass p-8 rounded-xl border border-white/10 hover:border-cyan-500/30 transition-all duration-300 group"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <p className="text-cyan-400 text-sm font-bold">{course.code}</p>
                    <h4 className="text-xl font-bold text-white mt-1 group-hover:text-cyan-300 transition-colors">
                      {course.title}
                    </h4>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold gradient-text">{course.rating}</p>
                    <p className="text-xs text-white/50">⭐ rating</p>
                  </div>
                </div>

                <p className="text-white/70 mb-6 text-sm leading-relaxed">{course.description}</p>

                <div className="flex items-center justify-between pt-4 border-t border-white/10">
                  <div className="flex items-center gap-2 text-white/60">
                    <FiUsers size={16} />
                    <span className="text-sm">{course.students} students</span>
                  </div>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    className="text-cyan-400 hover:text-cyan-300 text-sm font-semibold transition-colors"
                  >
                    View Course →
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Certifications */}
        <div>
          <motion.h3
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-3xl font-bold mb-8 flex items-center gap-3"
          >
            <FiAward className="text-purple-400" />
            Professional Certifications
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {certifications.map((cert, index) => (
              <motion.div
                key={cert.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ scale: 1.05, rotateZ: 2 }}
                className="glass p-6 rounded-lg border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 group cursor-pointer"
              >
                <div className="flex items-start justify-between mb-4">
                  <span className="text-4xl">{cert.badge}</span>
                  <span className="text-xs text-white/50">{cert.year}</span>
                </div>

                <h4 className="font-bold text-white mb-1 group-hover:text-purple-400 transition-colors">
                  {cert.name}
                </h4>
                <p className="text-sm text-white/60">{cert.issuer}</p>

                <motion.div
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="mt-4 h-1 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full origin-left"
                />
              </motion.div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20 pt-16 border-t border-white/10 grid md:grid-cols-3 gap-8"
        >
          <div className="text-center">
            <p className="text-4xl md:text-5xl font-bold gradient-text mb-2">500+</p>
            <p className="text-white/60">Students Educated</p>
          </div>
          <div className="text-center">
            <p className="text-4xl md:text-5xl font-bold gradient-text mb-2">8+</p>
            <p className="text-white/60">Years of Teaching</p>
          </div>
          <div className="text-center">
            <p className="text-4xl md:text-5xl font-bold gradient-text mb-2">4.8+</p>
            <p className="text-white/60">Average Rating</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
