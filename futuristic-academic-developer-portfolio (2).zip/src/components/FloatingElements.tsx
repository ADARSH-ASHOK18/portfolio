import React from 'react';
import { motion } from 'framer-motion';

interface FloatingElement {
  id: number;
  icon: string;
  delay: number;
  duration: number;
  position: { x: number; y: number };
  size: number;
}

export const FloatingElements: React.FC = () => {
  const elements: FloatingElement[] = [
    { id: 1, icon: '⚛️', delay: 0, duration: 8, position: { x: -100, y: -50 }, size: 40 },
    { id: 2, icon: '🚀', delay: 0.5, duration: 10, position: { x: 80, y: -100 }, size: 48 },
    { id: 3, icon: '💻', delay: 1, duration: 9, position: { x: -80, y: 100 }, size: 44 },
    { id: 4, icon: '🔬', delay: 1.5, duration: 11, position: { x: 100, y: 80 }, size: 40 },
    { id: 5, icon: '🤖', delay: 2, duration: 12, position: { x: -60, y: 150 }, size: 42 },
    { id: 6, icon: '📚', delay: 2.5, duration: 10, position: { x: 60, y: -150 }, size: 38 },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none" style={{ zIndex: 5 }}>
      {elements.map((element) => (
        <motion.div
          key={element.id}
          initial={{
            x: element.position.x,
            y: element.position.y,
            opacity: 0,
          }}
          animate={{
            x: [element.position.x, element.position.x + 40, element.position.x - 40, element.position.x],
            y: [element.position.y, element.position.y - 60, element.position.y + 60, element.position.y],
            opacity: [0, 0.6, 0.6, 0],
            rotate: [0, 360],
          }}
          transition={{
            duration: element.duration,
            delay: element.delay,
            repeat: Infinity,
            repeatType: 'loop',
            ease: 'linear',
          }}
          className="absolute text-center"
          style={{
            fontSize: element.size,
            filter: 'drop-shadow(0 0 10px rgba(34, 211, 238, 0.3))',
          }}
        >
          {element.icon}
        </motion.div>
      ))}
    </div>
  );
};
