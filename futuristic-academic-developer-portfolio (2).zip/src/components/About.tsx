import React from 'react';
import { motion } from 'framer-motion';
import { FiBook, FiUsers, FiAward, FiCode } from 'react-icons/fi';

const stats = [
  { icon: FiBook, label: 'Years of Teaching', value: '8+' },
  { icon: FiAward, label: 'Publications', value: '25+' },
  { icon: FiCode, label: 'Projects', value: '50+' },
  { icon: FiUsers, label: 'Students Mentored', value: '200+' },
];

const experience = [
  {
    period: '2020 - Present',
    title: 'Assistant Professor',
    company: 'Tech University',
    description: 'Leading research in web technologies, AI integration, and software architecture.',
  },
  {
    period: '2018 - 2020',
    title: 'Senior Full Stack Developer',
    company: 'Innovate Corp',
    description: 'Built scalable web applications serving millions of users globally.',
  },
  {
    period: '2016 - 2018',
    title: 'Full Stack Developer',
    company: 'StartUp Labs',
    description: 'Developed and deployed modern web applications using React and Node.js.',
  },
];

export const About: React.FC = () => {
  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/20 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">About Me</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            A passion-driven educator and technologist blending academic excellence with practical innovation.
          </p>
        </motion.div>

        {/* Bio Section */}
        <div className="grid md:grid-cols-2 gap-12 mb-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <p className="text-lg text-white/70 leading-relaxed">
              With over 8 years of experience in academia and industry, I'm dedicated to bridging the gap between theoretical research and real-world applications. My journey started with a deep interest in web technologies, which evolved into a passion for mentoring the next generation of developers and researchers.
            </p>
            <p className="text-lg text-white/70 leading-relaxed">
              As an Assistant Professor, I lead innovative research projects in AI integration, cloud computing, and full-stack web development. My work focuses on creating intelligent systems that solve complex problems and developing educational frameworks that empower students to succeed in the tech industry.
            </p>
            <div className="pt-6 flex gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="glass px-6 py-3 rounded-lg font-semibold text-white border border-cyan-500/50 hover:border-cyan-400"
              >
                Learn More
              </motion.button>
            </div>
          </motion.div>

          {/* Stats Grid */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="grid grid-cols-2 gap-6"
          >
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <motion.div
                  key={index}
                  whileHover={{ y: -10, boxShadow: '0 0 30px rgba(168, 85, 247, 0.3)' }}
                  className="glass p-6 rounded-xl border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 text-center group"
                >
                  <div className="flex justify-center mb-4 text-cyan-400 group-hover:text-purple-400 transition-colors">
                    <Icon size={32} />
                  </div>
                  <div className="text-3xl font-bold gradient-text mb-2">{stat.value}</div>
                  <p className="text-sm text-white/60">{stat.label}</p>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl font-bold text-center mb-12">Professional Journey</h3>
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500" />

            {/* Timeline items */}
            <div className="space-y-12">
              {experience.map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0 }}
                  whileInView={{ opacity: 1 }}
                  transition={{ duration: 0.8, delay: index * 0.2 }}
                  viewport={{ once: true }}
                  className={`flex ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
                >
                  <div className="w-1/2" />
                  <div className="w-12 flex justify-center">
                    <div className="w-6 h-6 rounded-full bg-gradient-to-r from-cyan-400 to-purple-400 border-4 border-slate-950 relative z-10" />
                  </div>
                  <motion.div
                    whileHover={{ x: index % 2 === 0 ? 10 : -10 }}
                    className={`w-1/2 ${index % 2 === 0 ? 'pl-8 pr-12' : 'pl-12 pr-8'}`}
                  >
                    <div className="glass p-6 rounded-lg border border-white/10 hover:border-cyan-500/30 transition-all duration-300">
                      <p className="text-cyan-400 text-sm font-semibold">{item.period}</p>
                      <h4 className="text-xl font-bold text-white mt-2">{item.title}</h4>
                      <p className="text-purple-400 font-semibold">{item.company}</p>
                      <p className="text-white/60 mt-3">{item.description}</p>
                    </div>
                  </motion.div>
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
