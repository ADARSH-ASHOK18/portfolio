import React from 'react';
import { motion } from 'framer-motion';

const timelineEvents = [
  {
    year: '2024',
    title: 'Innovation Excellence Award',
    description: 'Recognized for groundbreaking research in AI integration and web development',
    type: 'award',
    icon: '🏆',
  },
  {
    year: '2023',
    title: 'Published 5 Research Papers',
    description: 'Major contributions to journals in AI, Cloud Computing, and Web Technologies',
    type: 'research',
    icon: '📰',
  },
  {
    year: '2022',
    title: 'Promoted to Assistant Professor',
    description: 'Achieved tenure with focus on research and student mentorship',
    type: 'career',
    icon: '🎓',
  },
  {
    year: '2021',
    title: 'Launched AI Research Lab',
    description: 'Established cutting-edge research facility with 20+ ongoing projects',
    type: 'milestone',
    icon: '🔬',
  },
  {
    year: '2020',
    title: '500+ Students Taught',
    description: 'Successfully educated over 500 students in various technology domains',
    type: 'education',
    icon: '👥',
  },
  {
    year: '2019',
    title: 'Open Source Contributions',
    description: '10,000+ GitHub stars across multiple projects and frameworks',
    type: 'achievement',
    icon: '💻',
  },
];

export const Timeline: React.FC = () => {
  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-5xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Career Timeline</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Key milestones and achievements throughout my academic and professional journey.
          </p>
        </motion.div>

        {/* Timeline */}
        <div className="relative">
          {/* Center line */}
          <div className="absolute left-1/2 transform -translate-x-1/2 w-1 h-full bg-gradient-to-b from-cyan-500 via-purple-500 to-pink-500" />

          {/* Timeline items */}
          <div className="space-y-12">
            {timelineEvents.map((event, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 0.8, delay: index * 0.1 }}
                viewport={{ once: true }}
                className={`flex items-center ${index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'}`}
              >
                {/* Content */}
                <div className="w-1/2">
                  <motion.div
                    whileHover={{ x: index % 2 === 0 ? 10 : -10 }}
                    className={`glass p-6 rounded-xl border border-white/10 hover:border-cyan-500/30 transition-all duration-300 ${
                      index % 2 === 0 ? 'mr-12 text-left' : 'ml-12 text-right'
                    }`}
                  >
                    <div className="text-cyan-400 text-sm font-bold mb-2">{event.year}</div>
                    <h3 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                      {event.title}
                    </h3>
                    <p className="text-white/60 text-sm">{event.description}</p>
                  </motion.div>
                </div>

                {/* Center icon */}
                <div className="w-fit flex justify-center">
                  <motion.div
                    whileHover={{ scale: 1.2, rotate: 360 }}
                    transition={{ duration: 0.5 }}
                    className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-purple-500 border-4 border-slate-950 flex items-center justify-center relative z-10 cursor-pointer shadow-lg shadow-purple-500/50"
                  >
                    <span className="text-2xl">{event.icon}</span>
                  </motion.div>
                </div>

                {/* Placeholder for right side on left items */}
                <div className="w-1/2" />
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
