import React from 'react';
import { motion } from 'framer-motion';
import { FiGithub, FiLinkedin, FiTwitter, FiMail, FiArrowUp } from 'react-icons/fi';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const socialLinks = [
    { icon: FiGithub, href: 'https://github.com', label: 'GitHub' },
    { icon: FiLinkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
    { icon: FiTwitter, href: 'https://twitter.com', label: 'Twitter' },
    { icon: FiMail, href: 'mailto:alex@techuniversity.edu', label: 'Email' },
  ];

  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative border-t border-white/10 bg-gradient-to-b from-transparent to-purple-950/30 py-16 px-4" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Main Footer Content */}
        <div className="grid md:grid-cols-3 gap-12 mb-12">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h3 className="text-2xl font-bold gradient-text mb-2">Alex Chen</h3>
            <p className="text-white/60 text-sm">
              Assistant Professor • Full Stack Developer • Innovator
            </p>
          </motion.div>

          {/* Quick Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-white mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {['About', 'Projects', 'Research', 'Teaching', 'Contact'].map((link) => (
                <li key={link}>
                  <motion.a
                    href={`#${link.toLowerCase()}`}
                    whileHover={{ x: 5, color: '#06b6d4' }}
                    className="text-white/60 hover:text-cyan-400 transition-colors text-sm"
                  >
                    {link}
                  </motion.a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Newsletter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            viewport={{ once: true }}
          >
            <h4 className="font-semibold text-white mb-4">Stay Updated</h4>
            <p className="text-white/60 text-sm mb-4">Subscribe for research updates and tech insights</p>
            <div className="flex">
              <motion.input
                whileFocus={{ boxShadow: '0 0 15px rgba(34, 211, 238, 0.3)' }}
                type="email"
                placeholder="your@email.com"
                className="flex-1 glass px-4 py-2 rounded-l-lg border border-white/20 focus:border-cyan-500 focus:outline-none text-white placeholder-white/30 text-sm"
              />
              <motion.button
                whileHover={{ boxShadow: '0 0 20px rgba(168, 85, 247, 0.5)' }}
                whileTap={{ scale: 0.95 }}
                className="glass px-4 py-2 rounded-r-lg border border-white/20 border-l-0 focus:border-cyan-500 text-white font-semibold hover:border-purple-500/50 transition-all duration-300"
              >
                →
              </motion.button>
            </div>
          </motion.div>
        </div>

        {/* Social Links & Bottom */}
        <div className="border-t border-white/10 pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-8">
            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="flex gap-4"
            >
              {socialLinks.map((link, index) => {
                const Icon = link.icon;
                return (
                  <motion.a
                    key={index}
                    href={link.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={link.label}
                    initial={{ opacity: 0, scale: 0.8 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    viewport={{ once: true }}
                    whileHover={{
                      scale: 1.2,
                      boxShadow: '0 0 15px rgba(34, 211, 238, 0.5)',
                    }}
                    className="glass p-3 rounded-lg border border-white/20 hover:border-cyan-500/50 transition-all duration-300 text-white/60 hover:text-cyan-400"
                  >
                    <Icon size={20} />
                  </motion.a>
                );
              })}
            </motion.div>

            {/* Copyright */}
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              className="text-white/40 text-sm text-center md:text-left"
            >
              © {currentYear} Dr. Alex Chen. All rights reserved. Built with React, Tailwind CSS & Framer Motion.
            </motion.p>

            {/* Scroll to Top */}
            <motion.button
              onClick={scrollToTop}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              viewport={{ once: true }}
              whileHover={{ scale: 1.1, y: -5 }}
              whileTap={{ scale: 0.95 }}
              className="glass p-3 rounded-lg border border-white/20 hover:border-cyan-500/50 transition-all duration-300 text-white/60 hover:text-cyan-400"
              aria-label="Scroll to top"
            >
              <FiArrowUp size={20} />
            </motion.button>
          </div>
        </div>
      </div>

      {/* Floating particles background */}
      <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-purple-950/20 to-transparent pointer-events-none" />
    </footer>
  );
};
