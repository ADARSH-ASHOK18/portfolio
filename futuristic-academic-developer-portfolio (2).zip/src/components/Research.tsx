import React from 'react';
import { motion } from 'framer-motion';
import { FiBook, FiAward, FiGlobe, FiTrendingUp } from 'react-icons/fi';

const publications = [
  {
    id: 1,
    title: 'AI-Powered Web Development: A Comprehensive Framework for Intelligent Systems Integration',
    journal: 'International Journal of AI & Web Technologies',
    date: '2024',
    type: 'Journal',
    citations: 45,
  },
  {
    id: 2,
    title: 'Optimizing Real-time Collaborative Systems Using WebSocket Architecture',
    journal: 'IEEE Computer Society',
    date: '2023',
    type: 'Conference',
    citations: 32,
  },
  {
    id: 3,
    title: 'Machine Learning in Full-Stack Web Development: Practical Applications and Challenges',
    journal: 'ACM Digital Library',
    date: '2023',
    type: 'Journal',
    citations: 28,
  },
  {
    id: 4,
    title: 'Sustainable Web Architecture: Green Computing Practices for Modern Applications',
    journal: 'Software Engineering Today',
    date: '2022',
    type: 'Journal',
    citations: 19,
  },
  {
    id: 5,
    title: 'IoT Integration in Educational Systems: A Case Study in Smart Campus Development',
    journal: 'International Conference on EdTech',
    date: '2022',
    type: 'Conference',
    citations: 15,
  },
  {
    id: 6,
    title: 'Advanced Security Patterns for Microservices Architecture',
    journal: 'Cloud Computing Review',
    date: '2021',
    type: 'Journal',
    citations: 22,
  },
];

const achievements = [
  {
    icon: FiAward,
    title: 'Best Research Paper',
    description: 'Award for innovative research in web technologies',
    year: '2023',
  },
  {
    icon: FiTrendingUp,
    title: 'Tech Innovation Award',
    description: 'Recognition for cutting-edge development practices',
    year: '2023',
  },
  {
    icon: FiGlobe,
    title: 'International Speaker',
    description: 'Featured speaker at 15+ global conferences',
    year: '2022-2024',
  },
  {
    icon: FiBook,
    title: 'Published Author',
    description: 'Author of comprehensive technical guides and papers',
    year: '2021-2024',
  },
];

export const Research: React.FC = () => {
  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/20 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-6xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Research & Publications</span>
          </h2>
          <p className="text-xl text-white/60 max-w-2xl mx-auto">
            Academic contributions and research initiatives advancing the field of technology and education.
          </p>
        </motion.div>

        {/* Achievements Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {achievements.map((achievement, index) => {
            const Icon = achievement.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ y: -10, boxShadow: '0 0 30px rgba(168, 85, 247, 0.3)' }}
                className="glass p-6 rounded-xl border border-purple-500/20 hover:border-purple-500/50 transition-all duration-300 group text-center"
              >
                <div className="flex justify-center mb-4 text-cyan-400 group-hover:text-purple-400 transition-colors">
                  <Icon size={36} />
                </div>
                <h3 className="font-bold text-white mb-2">{achievement.title}</h3>
                <p className="text-sm text-white/60 mb-3">{achievement.description}</p>
                <p className="text-xs text-cyan-400">{achievement.year}</p>
              </motion.div>
            );
          })}
        </div>

        {/* Publications */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
        >
          <h3 className="text-3xl font-bold mb-8">Featured Publications</h3>
          <div className="space-y-4">
            {publications.map((pub, index) => (
              <motion.div
                key={pub.id}
                initial={{ opacity: 0, x: -40 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                viewport={{ once: true }}
                whileHover={{ x: 10, boxShadow: '0 0 30px rgba(6, 182, 212, 0.2)' }}
                className="glass p-6 rounded-lg border border-white/10 hover:border-cyan-500/30 transition-all duration-300 group cursor-pointer"
              >
                <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="px-3 py-1 rounded-full text-xs font-semibold bg-cyan-500/20 border border-cyan-500/30 text-cyan-300">
                        {pub.type}
                      </span>
                      <span className="text-sm text-white/50">{pub.date}</span>
                    </div>
                    <h4 className="text-lg font-bold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                      {pub.title}
                    </h4>
                    <p className="text-white/60 italic">{pub.journal}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="text-right">
                      <p className="text-2xl font-bold gradient-text">{pub.citations}</p>
                      <p className="text-xs text-white/50">citations</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* View All Link */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="glass px-8 py-4 rounded-lg font-semibold text-white border border-cyan-500/50 hover:border-cyan-400 hover:shadow-lg hover:shadow-cyan-500/50 transition-all duration-300"
          >
            View All Publications on Google Scholar
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
};
