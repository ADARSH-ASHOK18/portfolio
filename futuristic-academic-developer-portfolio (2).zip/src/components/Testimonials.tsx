import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiChevronLeft, FiChevronRight, FiStar } from 'react-icons/fi';

const testimonials = [
  {
    id: 1,
    name: 'Sarah Johnson',
    role: 'PhD Student',
    company: 'Tech University',
    image: '👩‍🎓',
    quote:
      'Dr. Chen\'s guidance was instrumental in shaping my research career. Their mentorship goes beyond academics – they inspire innovation and critical thinking.',
    rating: 5,
  },
  {
    id: 2,
    name: 'Michael Chen',
    role: 'Software Engineer',
    company: 'Google',
    image: '👨‍💼',
    quote:
      'The full-stack web development course was transformative. I applied what I learned immediately in my career and it elevated my skills significantly.',
    rating: 5,
  },
  {
    id: 3,
    name: 'Emily Rodriguez',
    role: 'AI Researcher',
    company: 'OpenAI',
    image: '👩‍🔬',
    quote:
      'Working with Dr. Chen on AI integration projects opened my eyes to practical applications of machine learning. An exceptional educator and mentor.',
    rating: 5,
  },
  {
    id: 4,
    name: 'James Wilson',
    role: 'Startup Founder',
    company: 'TechStartup Inc',
    image: '👨‍💻',
    quote:
      'The architectural insights and practical knowledge I gained have been crucial to scaling our application. Dr. Chen\'s experience is invaluable.',
    rating: 5,
  },
  {
    id: 5,
    name: 'Lisa Park',
    role: 'Product Manager',
    company: 'Meta',
    image: '👩‍💼',
    quote:
      'Dr. Chen brings both academic rigor and practical expertise. Their courses provided me with frameworks that I use every day in product development.',
    rating: 5,
  },
];

export const Testimonials: React.FC = () => {
  const [current, setCurrent] = useState(0);

  const next = () => {
    setCurrent((current + 1) % testimonials.length);
  };

  const prev = () => {
    setCurrent((current - 1 + testimonials.length) % testimonials.length);
  };

  const testimonial = testimonials[current];

  return (
    <section className="relative py-24 px-4 bg-gradient-to-b from-transparent via-purple-950/10 to-transparent" style={{ zIndex: 10 }}>
      <div className="max-w-4xl mx-auto">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl md:text-6xl font-bold mb-4">
            <span className="gradient-text">Student & Colleague Testimonials</span>
          </h2>
          <p className="text-xl text-white/60">
            Hear from students, researchers, and industry professionals who have worked with me.
          </p>
        </motion.div>

        {/* Testimonial Card */}
        <div className="relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={testimonial.id}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="glass p-8 md:p-12 rounded-2xl border border-white/10 hover:border-purple-500/30 transition-all duration-300"
            >
              {/* Quote Mark */}
              <div className="text-6xl text-cyan-400/20 mb-4">"</div>

              {/* Quote Text */}
              <p className="text-xl md:text-2xl text-white mb-8 leading-relaxed">
                {testimonial.quote}
              </p>

              {/* Rating */}
              <div className="flex gap-1 mb-8">
                {Array(testimonial.rating)
                  .fill(0)
                  .map((_, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, scale: 0 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: i * 0.1 }}
                    >
                      <FiStar className="text-yellow-400 fill-yellow-400" size={20} />
                    </motion.div>
                  ))}
              </div>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div className="text-4xl">{testimonial.image}</div>
                <div>
                  <h4 className="font-bold text-white text-lg">{testimonial.name}</h4>
                  <p className="text-cyan-400 text-sm">{testimonial.role}</p>
                  <p className="text-white/50 text-xs">{testimonial.company}</p>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex items-center justify-between mt-8">
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={prev}
              className="glass p-3 rounded-lg border border-white/20 hover:border-cyan-500/50 transition-all duration-300 text-white/60 hover:text-cyan-400"
            >
              <FiChevronLeft size={24} />
            </motion.button>

            {/* Indicators */}
            <div className="flex gap-2">
              {testimonials.map((_, index) => (
                <motion.button
                  key={index}
                  onClick={() => setCurrent(index)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    index === current ? 'w-8 bg-gradient-to-r from-cyan-400 to-purple-400' : 'w-2 bg-white/20'
                  }`}
                  whileHover={{ scale: 1.2 }}
                />
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              onClick={next}
              className="glass p-3 rounded-lg border border-white/20 hover:border-cyan-500/50 transition-all duration-300 text-white/60 hover:text-cyan-400"
            >
              <FiChevronRight size={24} />
            </motion.button>
          </div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="mt-20 pt-16 border-t border-white/10 grid grid-cols-1 md:grid-cols-3 gap-8"
        >
          <div className="text-center">
            <p className="text-4xl font-bold gradient-text mb-2">500+</p>
            <p className="text-white/60">Students Mentored</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold gradient-text mb-2">4.9/5</p>
            <p className="text-white/60">Average Rating</p>
          </div>
          <div className="text-center">
            <p className="text-4xl font-bold gradient-text mb-2">100%</p>
            <p className="text-white/60">Recommend Me</p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
